import React, { useState, useEffect } from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";

function About() {
  const [photos, setPhotos] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/photos")
      .then((resp) => resp.json())
      .then((data) => {
        setPhotos(data);
        setLoading(false);
      });
  }, []);
  return (
    <div>
      <Header />
      {/* Page Header End */}
      <div className="container-xxl py-5 page-header position-relative mb-5">
        <div className="container py-5">
          <h1 className="display-2 text-white animated slideInDown mb-4">
            About Us
          </h1>
          <nav aria-label="breadcrumb animated slideInDown">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <a href="/">Home</a>
              </li>
              <li className="breadcrumb-item">
                <a href="/">Pages</a>
              </li>
              <li
                className="breadcrumb-item text-white active"
                aria-current="page"
              >
                About Us
              </li>
            </ol>
          </nav>
        </div>
      </div>
      {/* Page Header End */}
      <div>
        <h2>About Component</h2>
        {loading ? (
          <div>Loading...</div>
        ) : (
          <div className="row">
            {photos.map((photo) => (
              <div className="col-md-3" key={photo.id}>
                <div className="card">
                  <img src={photo.thumbnailUrl} alt={photo.title} />
                  <div className="card-body">
                    <h5 className="card-title">{photo.title}</h5>
                    <p className="card-text">{photo.albumId}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}

export default About;
